﻿namespace QuickstartIdentityServer
{
	public class UserRepository
	{
		
	}
}